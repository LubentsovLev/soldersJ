/*

(function scrollReveal() {

  window.sr = ScrollReveal();
  
  sr.reveal('.des-text h2', {
    duration   : 900,
    distance   : '70px',
    easing     : 'ease-out',
    origin     : 'bottom',
    delay: 1200,
    reset      : false,
    scale      : 1,
    viewFactor : 0,
    afterReveal  : revealChildren,
  }, 150);
  sr.reveal('.des-text p', {
    duration   : 900,
    distance   : '70px',
    easing     : 'ease-out',
    origin     : 'bottom',
    delay: 1200,
    reset      : false,
    scale      : 1,
    viewFactor : 0,
    afterReveal  : revealChildren,
  }, 150);

    sr.reveal('.button-sc', {
     duration   : 900,
    distance   : '70px',
    easing     : 'ease-out',
    origin     : 'bottom',
    delay: 1200,
    reset      : false,
    scale      : 1,
    viewFactor : 0,
    afterReveal  : revealChildren,
  }, 150);


    sr.reveal('.com-img img', {
    duration   : 900,
    distance   : '70px',
    easing     : 'ease-in-out',
    origin     : 'right',
    delay: 1400,
    reset      : false,
    scale      : 1,
    viewFactor : 0,
    afterReveal  : revealChildren,
  }, 150);

   sr.reveal('.main-heading h2', {
       duration   : 900,
    distance   : '70px',
    easing     : 'ease-out',
    origin     : 'bottom',
    delay: 1200,
    reset      : false,
    scale      : 1,
    viewFactor : 0,
    afterReveal  : revealChildren,
  }, 150);

  sr.reveal('.description-sc .team-box', {
        duration   : 900,
    distance   : '70px',
    easing     : 'ease-out',
    origin     : 'bottom',
    delay: 1200,
    reset      : false,
    scale      : 1,
    viewFactor : 0,
    afterReveal  : revealChildren,
  }, 150);

    sr.reveal('.gearup-sc .img-gall', {
        duration   : 900,
    distance   : '70px',
    easing     : 'ease-out',
    origin     : 'bottom',
    delay: 1200,
    reset      : false,
    scale      : 1,
    viewFactor : 0,
    afterReveal  : revealChildren,
  }, 150);

  sr.reveal('.footer-social', {
        duration   : 900,
    distance   : '70px',
    easing     : 'ease-out',
    origin     : 'bottom',
    delay: 1200,
    reset      : false,
    scale      : 1,
    viewFactor : 0,
    afterReveal  : revealChildren,
  }, 150);
  sr.reveal('.des-num', {
        duration   : 900,
    distance   : '70px',
    easing     : 'ease-out',
    origin     : 'left',
    delay: 1200,
    reset      : false,
    scale      : 1,
    viewFactor : 0,
    afterReveal  : revealChildren,
  }, 150);
  sr.reveal('.des-gif', {
       duration   : 900,
    distance   : '70px',
    easing     : 'ease-out',
    origin     : 'right',
    delay: 1200,
    reset      : false,
    scale      : 1,
    viewFactor : 0,
    afterReveal  : revealChildren,
  }, 150);

 sr.reveal('.mnd', {
        duration   : 900,
    distance   : '70px',
    easing     : 'ease-out',
    origin     : 'bottom',
    delay: 1200,
    reset      : false,
    scale      : 1,
    viewFactor : 0,
    afterReveal  : revealChildren,
  }, 150);


 sr.reveal('.mindmap-sc .des-text h2', {
    duration   : 500,
    distance   : '70px',
    easing     : 'ease-out',
    origin     : 'bottom',
    delay: 0,
    reset      : false,
    scale      : 1,
    viewFactor : 0,
    afterReveal  : revealChildren,
  }, 150);
  sr.reveal('.mindmap-sc .des-text p', {
    duration   : 500,
    distance   : '70px',
    easing     : 'ease-out',
    origin     : 'bottom',
    delay: 00,
    reset      : false,
    scale      : 1,
    viewFactor : 0,
    afterReveal  : revealChildren,
  }, 150);





    var revealChildren = sr.reveal('.card-title, .card-text', {
    duration   : 500,
    scale      : 0.5,
    delay: 300,
    distance   : '20px',
    origin     : 'bottom',
    reset      : false,
    easing     : 'ease-out',
    viewFactor : 1,
  }, 75);
})();

*/

















         /*
         $(window).scroll(function() {
           var $header = $('header');
           if ($(this).scrollTop() > 100) {
             if (!$header.hasClass('sticky')) $header.addClass("sticky");
           } else {
             if ($header.hasClass('sticky')) $header.removeClass("sticky");
           }
         });
         $('.smoothScroll').on('click', function(e) {
           e.preventDefault();
           var $target = $($(this).attr('data'));
           var $header = $('.header');
           $('html, body').animate({
             scrollTop: $target.offset().top - $header.height() + 50 + 'px'
           }, 300);
         });
  */





/*function army() {
  var element = document.getElementById("changeTheme");
  element.classList.add("army");
  element.classList.remove("navy", "airforce", "cartoon");
}
function navy() {
  var element = document.getElementById("changeTheme");
  element.classList.add("navy");
  element.classList.remove("army", "airforce", "cartoon");
}
function airforce() {
  var element = document.getElementById("changeTheme");
  element.classList.add("airforce");
  element.classList.remove("army", "navy", "cartoon");
}
function cartoon() {
  var element = document.getElementById("changeTheme");
  element.classList.add("cartoon");
  element.classList.remove("army", "navy", "airforce");
}
*/